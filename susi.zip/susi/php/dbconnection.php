<?php
	 $link=mysqli_connect("localhost","root","","testteacherdb")
	 or die('error connectiong to mysql server');

?>
