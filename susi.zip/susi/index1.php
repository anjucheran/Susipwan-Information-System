<?php
	if(!empty($_POST["forgot-password"])){
		$conn = mysqli_connect("localhost", "root", "", "Member");

		$condition = "";
		if(!empty($_POST["user-login-name"]))
			$condition = " member_name = '" . $_POST["user-login-name"] . "'";
			//echo  $_POST["user-login-name"] ;
		if(!empty($_POST["user-email"])) {
			if(!empty($condition)) {
				$condition = " and ";
			}
			$condition = " member_email = '" . $_POST["user-email"] . "'";
		}

		if(!empty($condition)) {
			$condition = " where " . $condition;
		}
		//echo $condition;

		$sql = "Select * from members " . $condition;
		//echo $sql;
		$result = mysqli_query($conn,$sql);
		$user = mysqli_fetch_array($result);


		if(!empty($user)) {
			include_once 'forgot-password-recovery-mail.php';
			require_once("forgot-password-recovery-mail.php");
		} else {
			$error_message = 'No User Found';
		}
	}
?>



	<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	      <meta charset="utf-8" />
	    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	    <title>SUSIPWAN Classes</title>

	    <!-- BOOTSTRAP STYLES-->
	    <link href="css/bootstrap.css" rel="stylesheet" />
	    <!-- FONTAWESOME STYLES-->
	    <link href="css/font-awesome.css" rel="stylesheet" />
	    <!-- GOOGLE FONTS-->
	    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



<style>
.myhead{
margin-top:0px;
margin-bottom:0px;
text-align:center;
}
</style>

</head>
<body >
		<div class="container">

				 <div class="row ">

								<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">

														<div class="panel-body" style="background-color: #E2E2E2; margin-top:50px; border:solid 3px #0e0e0e;">
															<h3 class="myhead">Forgot Password?</h3>
															  <hr />
<script>
function validate_forgot() {
	if((document.getElementById("user-login-name").value == "") && (document.getElementById("user-email").value == "")) {
		document.getElementById("validation-message").innerHTML = "Login name or Email is required!"
		return false;
	}
	return true
}
</script>

<form name="frmForgot" id="frmForgot" method="post" onSubmit="return validate_forgot();">

	<?php if(!empty($success_message)) { ?>
	<div class="success_message"><?php echo $success_message; ?></div>
	<?php } ?>

	<div id="validation-message">
		<?php if(!empty($error_message)) { ?>
	<?php echo $error_message; ?>
	<?php } ?>
	</div>


												<div class="form-group input-group">
													<span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
													<input type="text" name="user-login-name" id="user-login-name" placeholder="Your Username "class="form-control">

											</div>
											<div>Or</div>

											<div class="form-group input-group">
												<span class="input-group-addon"><i class="fa fa-envelope"  ></i></span>

												<div><input type="text" name="user-email" id="user-email" placeholder="Your Email "class="form-control"></div>
											</div>

											<div class="field-group">
												<div><input type="submit" name="forgot-password" id="forgot-password" value="Submit" class="btn btn-primary"></div>
											</div>


											<br></br>

						    	<div id="footer-sec">
								 	SUSIPWAN Classes | Developed By : <a href="https://github.com/deHasara" target="_blank">cyberX.com</a>
								 </div>


</form>


	                            </div>

	                        </div>


	        </div>
	    </div>

		</body>
		</html>
