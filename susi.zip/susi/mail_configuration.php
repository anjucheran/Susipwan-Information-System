<?php
define("PROJECT_HOME","http://localhost/susi");

define("PORT", "587"); // port number
define("MAIL_USERNAME", "123silvakhm@gmail.com"); // smtp usernmae
define("MAIL_PASSWORD", "chandi123"); // smtp password
define("MAIL_HOST", "smtp.gmail.com"); // smtp host
define("MAILER", "smtp");

define("SENDER_NAME", "Admin");
define("SERDER_EMAIL", "123silvakhm@gmail.com");
?>
